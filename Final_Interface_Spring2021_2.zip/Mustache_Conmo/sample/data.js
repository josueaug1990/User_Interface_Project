$(document).ready(function() {

    // Define variables that reference our script tags within the body of our page
    var topNavigation = $("#topNavigation").html();
    var sideNavigation = $("#sideNavigation").html();

    // Have MustacheJS render our script tags
    Mustache.parse(topNavigation);
    Mustache.parse(sideNavigation);

    // Define our data objects
    var topNav = Mustache.render(topNavigation, {
        item: [{
                name: "Home",
                link: "#"
            },
            {
                name: "About",
                link: "#"
            },
            {
                name: "Toys",
                link: "#"
            }
        ]
    });

    var sideNav = Mustache.render(sideNavigation, {
        item: [{
                name: "Arts & Crafts",
                link: "#",
                image: "artsCrafts_thumb.jpg",
                altTag: "Etch A Sketch"
            },
            {
                name: "Electronics",
                link: "#",
                image: "electronics_thumb.jpg",
                altTag: "Electronic Toy"
            },
            {
                name: "Games",
                link: "#",
                image: "games_thumb.jpg",
                altTag: "Catan"
            },
            {
                name: "Hobbies",
                link: "#",
                image: "./images/hobbies_thumb.jpg",
                altTag: "Plane"
            }
        ]
    });

    // Place data into the HTML of our page with the html() jQuery method
    $("#render_topLinks").html(topNav);
    $("#render_sideLinks").html(sideNav);

    // Insert current year into the Copyright text in the footer.  Note: MustacheJS is not needed to do this.
    $("#currentYear").html(new Date().getFullYear());

});